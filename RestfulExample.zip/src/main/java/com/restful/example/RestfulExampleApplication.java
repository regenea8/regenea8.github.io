package com.restful.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestfulExampleApplication.class, args);
	}

}
