package com.restful.example.comm;

import java.net.URLDecoder;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class SendRequest {

	private static Logger LOGGER = LoggerFactory.getLogger(SendRequest.class);

	@Autowired
	RestTemplate restTemplate;
	
	public ResponseEntity<String> send(String url, HttpServletRequest request,
			HttpMethod method, Map<String, String> addHeaders) {

		HttpEntity<String> reqEntity = null;
		HttpHeaders reqHeaders = new HttpHeaders();
		HttpHeaders resHeaders = new HttpHeaders();

		// RequestHeader 추가
		if (addHeaders != null && addHeaders.size() > 0) {
			Iterator<String> iterator = addHeaders.keySet().iterator();
			while (iterator.hasNext()) {
				String key = iterator.next();
				String value = addHeaders.get(key);
				reqHeaders.add(key, value);
			}
		}
		
		ResponseEntity<String> restTemplateResponse = null;
		
		String params = null;
		String querys = null;
		
		try {
			
			if (method == HttpMethod.GET) {
				querys = URLDecoder.decode(request.getQueryString(), "UTF-8");
				url = url + "?" + querys;
				LOGGER.debug("REQ_QUERY={}", url);
			} else {
				params = CommonUtils.getBody(request);
				LOGGER.debug("REQ_PARAMS={}", params);
			}
			
			reqEntity = new HttpEntity<String>(params, reqHeaders);
			restTemplateResponse = restTemplate.exchange(url, method, reqEntity, String.class);
			
		} catch (Exception e) {
			LOGGER.error("", e);
			return new ResponseEntity<String>(e.toString(), resHeaders, HttpStatus.EXPECTATION_FAILED);
		}

		return new ResponseEntity<String>(restTemplateResponse.getBody().toString(), resHeaders,
				restTemplateResponse.getStatusCode());
	}
	
}
